var FhcpConst ={
	
	 shape_triangle : 'triangle',//三角
	 shape_quadrangle :'quadrangle',//四角
	 shape_circular:'circular'
};