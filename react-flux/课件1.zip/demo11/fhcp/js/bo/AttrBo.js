/**
 * 属性信息基本数据模型类
 * 庄召添加
 */

var AttrStyleBo = {};

//样式的基本属性
AttrStyleBo.prototype = {
	//字体类
	fontSize:14,
	fontType:''
	
	//颜色类
};
