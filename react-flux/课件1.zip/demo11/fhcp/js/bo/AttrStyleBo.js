/**
 * 属性信息
 * 庄召添加
 */

var AttrBo = {};

//样式的基本属性
AttrBo.prototype = {
   webbenAttr:null,
   pailieAttr:null,
   styleAttr:null
   
};
