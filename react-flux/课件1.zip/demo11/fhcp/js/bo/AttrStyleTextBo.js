/**
 * 文本样式属性信息基本数据模型类
 * 庄召添加
 */

var AttrStyleTextBo = {};
//继承基本属性
AttrStyleTextBo.prototype=new  AttrStyleBo();
AttrStyleTextBo.prototype = {
		//对齐类
	
}
