import {h, render, Component, cloneElement} from 'preact';
import AppView from './views/AppView';
import './styles/app.css';

render(<AppView />, document.body);